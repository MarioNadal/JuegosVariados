package com.iessanalberto.dam2.juegosvariados.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.navigation.NavController
import com.iessanalberto.dam2.juegosvariados.navigation.AppScreens

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PiedraPapelTijeraScreen(navController: NavController){
    var puntuacionJug by remember {mutableStateOf(0)}
    var puntuacionMaq by remember {mutableStateOf(0)}
    var mostrarAlertDialog by remember { mutableStateOf(false)}
    var numeroMaquina = (Math.random() * 3) + 1
    var numeroMaquinaInt = numeroMaquina.toInt()
    var piedraPapelTijera by remember {mutableStateOf("")}
    var piedraPapelTijeraMaq by remember {mutableStateOf("")}
    Scaffold(
        topBar = { CenterAlignedTopAppBar(
            title = { Text(text = "Jugador: $puntuacionJug   Máquina: $puntuacionMaq")},
            colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                containerColor = MaterialTheme.colorScheme.primaryContainer,
                titleContentColor = MaterialTheme.colorScheme.primary
            ))
        }
    )
    {innerPadding->
        Column(modifier = Modifier
            .fillMaxSize()
            .padding(innerPadding),
            verticalArrangement = Arrangement.SpaceEvenly,
            horizontalAlignment = Alignment.CenterHorizontally)
        {
            Text(text = "Elige piedra, papel o tijera")
            OutlinedTextField(value = piedraPapelTijera, onValueChange = {piedraPapelTijera=it})

            if(mostrarAlertDialog) {
                if (piedraPapelTijeraMaq == "piedra") {
                    if (piedraPapelTijera == "piedra") {
                        AlertDialog(
                            title = { Text(text = "Juego") },
                            text = { Text(text = "Yo saco $piedraPapelTijeraMaq. \n Empate.") },
                            onDismissRequest = { mostrarAlertDialog=false },
                            confirmButton = {
                                TextButton(onClick = { mostrarAlertDialog=false }) {
                                    Text(text = "OK")
                                }
                            })
                    } else if (piedraPapelTijera == "papel") {
                        AlertDialog(
                            title = { Text(text = "Juego") },
                            text = { Text(text = "Yo saco $piedraPapelTijeraMaq. \n Gana Jugador.") },
                            onDismissRequest = { mostrarAlertDialog=false
                                puntuacionJug++},
                            confirmButton = {
                                TextButton(onClick = { mostrarAlertDialog=false
                                    puntuacionJug++}) {
                                    Text(text = "OK")
                                }
                            })
                    } else if (piedraPapelTijera == "tijera") {
                        AlertDialog(
                            title = { Text(text = "Juego") },
                            text = { Text(text = "Yo saco $piedraPapelTijeraMaq. \n Gana Máquina.") },
                            onDismissRequest = { mostrarAlertDialog=false
                                               puntuacionMaq++},
                            confirmButton = {
                                TextButton(onClick = { mostrarAlertDialog=false
                                    puntuacionMaq++}) {
                                    Text(text = "OK")
                                }
                            })
                    }
                } else if (piedraPapelTijeraMaq == "papel") {
                    if (piedraPapelTijera == "piedra") {
                        AlertDialog(
                            title = { Text(text = "Juego") },
                            text = { Text(text = "Yo saco $piedraPapelTijeraMaq. \n Gana Máquina.") },
                            onDismissRequest = { mostrarAlertDialog=false
                                               puntuacionMaq++},
                            confirmButton = {
                                TextButton(onClick = { mostrarAlertDialog=false
                                    puntuacionMaq++}) {
                                    Text(text = "OK")
                                }
                            })
                    } else if (piedraPapelTijera == "papel") {
                        AlertDialog(
                            title = { Text(text = "Juego") },
                            text = { Text(text = "Yo saco $piedraPapelTijeraMaq. \n Empate.") },
                            onDismissRequest = { mostrarAlertDialog=false },
                            confirmButton = {
                                TextButton(onClick = { mostrarAlertDialog=false }) {
                                    Text(text = "OK")
                                }
                            })
                    } else if (piedraPapelTijera == "tijera") {
                        AlertDialog(
                            title = { Text(text = "Juego") },
                            text = { Text(text = "Yo saco $piedraPapelTijeraMaq. \n Gana Jugador.") },
                            onDismissRequest = { mostrarAlertDialog=false
                                puntuacionJug++},
                            confirmButton = {
                                TextButton(onClick = { mostrarAlertDialog=false
                                    puntuacionJug++}) {
                                    Text(text = "OK")
                                }
                            })
                    }
                } else if (piedraPapelTijeraMaq == "tijera") {
                    if (piedraPapelTijera == "piedra") {
                        AlertDialog(
                            title = { Text(text = "Juego") },
                            text = { Text(text = "Yo saco $piedraPapelTijeraMaq. \n Gana Jugador.") },
                            onDismissRequest = { mostrarAlertDialog=false
                                puntuacionJug++},
                            confirmButton = {
                                TextButton(onClick = { mostrarAlertDialog=false
                                    puntuacionJug++}) {
                                    Text(text = "OK")
                                }
                            })
                    } else if (piedraPapelTijera == "papel") {
                        AlertDialog(
                            title = { Text(text = "Juego") },
                            text = { Text(text = "Yo saco $piedraPapelTijeraMaq. \n Gana Máquina.") },
                            onDismissRequest = { mostrarAlertDialog=false
                                               puntuacionMaq++},
                            confirmButton = {
                                TextButton(onClick = { mostrarAlertDialog=false
                                puntuacionMaq++}) {
                                    Text(text = "OK")
                                }
                            })
                    } else if (piedraPapelTijera == "tijera") {
                        AlertDialog(
                            title = { Text(text = "Juego") },
                            text = { Text(text = "Yo saco $piedraPapelTijeraMaq. \n Empate.") },
                            onDismissRequest = { mostrarAlertDialog=false },
                            confirmButton = {
                                TextButton(onClick = { mostrarAlertDialog=false }) {
                                    Text(text = "OK")
                                }
                            })
                    }
                }
            }

            Button(onClick = {
                mostrarAlertDialog=true
                numeroMaquina = (Math.random() * 3) + 1
                numeroMaquinaInt = numeroMaquina.toInt()
                if (numeroMaquinaInt == 1) {
                    piedraPapelTijeraMaq = "piedra"
                } else if (numeroMaquinaInt == 2) {
                    piedraPapelTijeraMaq = "papel"
                } else {
                    piedraPapelTijeraMaq = "tijera"
                }
            }) {
                Text(text = "Jugar")
            }

            if(mostrarAlertDialog){
                if(puntuacionMaq==3){
                    AlertDialog(
                        title = { Text(text = "Juego Finalizado") },
                        text = { Text(text = "Ha ganado la máquina.") },
                        onDismissRequest = { mostrarAlertDialog=false
                            navController.navigate(route= AppScreens.MainScreen.route)},
                        confirmButton = {
                            TextButton(onClick = { mostrarAlertDialog=false
                                navController.navigate(route= AppScreens.MainScreen.route)}) {
                                Text(text = "OK")
                            }
                        })
                }else if (puntuacionJug==3){
                    AlertDialog(
                        title = { Text(text = "Juego Finalizado") },
                        text = { Text(text = "Ha ganado jugador.") },
                        onDismissRequest = { mostrarAlertDialog=false
                            navController.navigate(route= AppScreens.MainScreen.route)},
                        confirmButton = {
                            TextButton(onClick = { mostrarAlertDialog=false
                                navController.navigate(route= AppScreens.MainScreen.route)}) {
                                Text(text = "OK")
                            }
                        })
                }
            }
        }
    }

}