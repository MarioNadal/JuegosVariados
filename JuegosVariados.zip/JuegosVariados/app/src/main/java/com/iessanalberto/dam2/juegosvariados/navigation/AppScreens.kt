package com.iessanalberto.dam2.juegosvariados.navigation

sealed class AppScreens (val route: String) {
    object MainScreen: AppScreens (route = "main_screen")
    object NonesScreen: AppScreens (route = "nones_screen")
    object PiedraPapelTijeraScreen : AppScreens(route = "piedraPapelTijera_screen")
}
