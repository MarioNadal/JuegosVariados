package com.iessanalberto.dam2.juegosvariados.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.navigation.NavController
import com.iessanalberto.dam2.juegosvariados.navigation.AppScreens

@Composable
fun MainScreen(navController: NavController){
    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally){
        Button(onClick = { navController.navigate(route= AppScreens.NonesScreen.route)}) {
            Text(text = "Pares o nones")
        }
        Button(onClick = { /*TODO*/ }){

        }
        Button(onClick = { /*TODO*/ }) {
            
        }
        Button(onClick = { /*TODO*/ }) {
            
        }
    }
}