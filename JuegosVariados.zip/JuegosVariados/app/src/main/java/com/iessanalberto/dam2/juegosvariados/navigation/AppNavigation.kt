package com.iessanalberto.dam2.juegosvariados.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.iessanalberto.dam2.juegosvariados.screens.MainScreen
import com.iessanalberto.dam2.juegosvariados.screens.NonesScreen
import com.iessanalberto.dam2.juegosvariados.screens.PiedraPapelTijeraScreen

@Composable
fun AppNavigation(){
    val navController = rememberNavController()
    NavHost(navController = navController, startDestination = AppScreens.MainScreen.route ){
        composable(route= AppScreens.MainScreen.route){MainScreen(navController)}
        composable(route= AppScreens.NonesScreen.route){NonesScreen(navController)}
        composable(route= AppScreens.PiedraPapelTijeraScreen.route){ PiedraPapelTijeraScreen(navController)}
    }

}

