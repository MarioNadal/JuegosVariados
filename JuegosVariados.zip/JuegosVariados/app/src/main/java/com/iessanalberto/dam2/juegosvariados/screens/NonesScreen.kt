package com.iessanalberto.dam2.juegosvariados.screens

import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.NavController
import com.iessanalberto.dam2.juegosvariados.navigation.AppScreens

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NonesScreen(navController: NavController){
    var suma = 0
    var puntuacionJug by remember {mutableStateOf(0)}
    var puntuacionMaq by remember {mutableStateOf(0)}
    var mostrarAlertDialog by remember { mutableStateOf(false)}
    var numeroMaquina = (Math.random() * 3)
    var numeroMaquinaInt = numeroMaquina.toInt()
    var numeroJugador by remember { mutableStateOf("")}
    var paresONones by remember {mutableStateOf("")}
    var resultado = ""
    var context = LocalContext.current

    Scaffold(
        topBar = { CenterAlignedTopAppBar(
                //Mostramos la puntuacion del jugador y de la máquina
                title = { Text(text = "Jugador: $puntuacionJug   Máquina: $puntuacionMaq")},
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.primary
        ))
        }
    )
    {innerPadding->
        Column(modifier = Modifier
            .fillMaxSize()
            .padding(innerPadding),
            verticalArrangement = Arrangement.SpaceEvenly,
            horizontalAlignment = Alignment.CenterHorizontally)
        {
            Text(text = "Elige pares o nones")
            //El usuario debe introducir si juega pares o nones
            OutlinedTextField(value = paresONones, onValueChange = {paresONones=it})
            Text(text = "Elige la tirada (0-3)")
            //EL usuario debe elegir cuantos dedos saca entre 0 y 3
            OutlinedTextField(value = numeroJugador, onValueChange = {numeroJugador=it})
            if(mostrarAlertDialog){
                //Si el jugador ha elegido el valor ganador entra
                if (paresONones == resultado) {
                    AlertDialog(
                        title = { Text(text = "Juego") },
                        //Le dice lo que ha sacado la máquina, la suma que da, el valor que gana e informa al jugador de que ha ganado
                        text = { Text(text = "Yo saco $numeroMaquinaInt. La suma es $suma. \n El ganador es $resultado. \n Tu ganas") },
                        //Sumamos en cualquier método de salida un punto al jugador y dejamos de mostrar el Alert Dialog
                        onDismissRequest = { mostrarAlertDialog=false
                            puntuacionJug++},
                        confirmButton = {
                            TextButton(onClick = { mostrarAlertDialog=false
                                puntuacionJug++}) {
                                Text(text = "OK")
                            }
                        })
                    //Si el jugador ha perdido
                    } else {
                        AlertDialog(
                            title = { Text(text = "Juego") },
                            //Le dice lo que ha sacado la máquina, la suma, el valor que gana e informa al jugador de que ha ganado la máquina
                            text = { Text(text = "Yo saco $numeroMaquinaInt. La suma es $suma. \n El ganador es $resultado. \n Yo gano") },
                            //Sumamos en cualquier método de salida un punto a la máquina y dejamos de mostrar el Alert Dialog
                            onDismissRequest = {mostrarAlertDialog=false
                                puntuacionMaq++},
                            confirmButton = {
                                TextButton(onClick = { mostrarAlertDialog=false
                                    puntuacionMaq++}) {
                                    Text(text = "OK")
                                }
                            })
                    }
                    //Renovamos el número de la máquina para la siguiente jugada si hubiese
                    numeroMaquina = (Math.random() * 3)
                }
            //Si después de la última jugada la máquina ha conseguido el 3er punto gana
            if(puntuacionMaq==3){
                AlertDialog(
                    title = { Text(text = "Juego Finalizado") },
                    //Le decimos al jugador que ha ganado la máquina
                    text = { Text(text = "Ha ganado la máquina.") },
                    //En cualquier método de salida vuelve a la pantalla de seleccion de juegos
                    onDismissRequest = { mostrarAlertDialog=false
                        navController.navigate(route= AppScreens.MainScreen.route)},
                    confirmButton = {
                        TextButton(onClick = { mostrarAlertDialog=false
                            navController.navigate(route= AppScreens.MainScreen.route)}) {
                            Text(text = "OK")
                        }
                    })
            //Si después de la última jugada el jugador ha conseguido el 3er punto gana
            }else if (puntuacionJug==3){
                AlertDialog(
                    title = { Text(text = "Juego Finalizado") },
                    //Le decimos al jugador que ha ganado
                    text = { Text(text = "Ha ganado jugador.") },
                    //En cualquier método de salida vuelve a la pantalla de seleccion de juegos
                    onDismissRequest = { mostrarAlertDialog=false
                        navController.navigate(route= AppScreens.MainScreen.route)},
                    confirmButton = {
                        TextButton(onClick = { mostrarAlertDialog=false
                            navController.navigate(route= AppScreens.MainScreen.route)}) {
                            Text(text = "OK")
                        }
                    })
            }
            Button(onClick = {
                //Al hacer click en el boton comprueba que el jugador haya introducido valores válidos en ambos campos
                if((paresONones=="pares"||paresONones=="nones")&&(numeroJugador=="0"||numeroJugador=="1"||numeroJugador=="2"||numeroJugador=="3")){
                    numeroMaquina = (Math.random() * 3)
                    //Pasa el valor de dedos de la máquina a int para que se pueda sumar
                    numeroMaquinaInt = numeroMaquina.toInt()
                    //Sumamos los dedos de la máquina y del jugador
                    suma = numeroMaquina.toInt() + numeroJugador.toInt()
                    //Dependiendo del resto de la suma sabremos si es par o impar
                    if(suma%2==0){
                        resultado = "pares"
                    }else{
                        resultado = "nones"
                    }
                    //Después haremos que salga el Alert Dialog mostrando lo que ha pasado
                    mostrarAlertDialog=true
                //Si el usuario ha introducido algún valor invalido en algun campo le sale un toast pidiendole que los rellene bien
                }else{
                    Toast.makeText(context,"Debes introducir valores válidos en ambos campos.", Toast.LENGTH_SHORT).show()
                }
                }
            ) {
                Text(text = "Jugar")
            }

        }
    }

}